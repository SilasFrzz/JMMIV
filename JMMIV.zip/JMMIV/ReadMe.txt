This is a c++ port of an old python project from 2019
it might be buggy I don't know
have fun :)